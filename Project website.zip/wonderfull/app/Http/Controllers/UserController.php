<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Articles;
use App\Category;
use App\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class UserController extends Controller
{
    //update, delete articles, add articles

    public function muncul_articles(){ // untuk melihat articles
        $articles = Articles::all();
        return view ('blog', ['articles'=>$articles]);
    }

    public function delete($id){ // untuk delete articles
        DB::table('articles')->where('id',$id)->delete();
        return redirect('/blog');
    }
    public function AddArticles(Request $request){ // untuk menambah articles
        $validator = Validator::make($request->all(), [
            'title'=>'required|max:255',
            'description' => 'required|max:1000',
            'addcategory' => 'required|numeric',
            'articles_image' => 'required'
        ]);
        if ($validator->fails()) {
            return redirect('add')
                        ->withErrors($validator)
                        ->withInput();
        }
        
        $image = $request->file('articles_image');
        $image->move(public_path('asset/'.strtolower(Str::replaceLast(' ','',$request->Category))),$image->getClientOriginalName());
        $category_id = Category::where('name','like','%'.$request->Category.'%')->first();
        DB::table('articles')->insert(
            ['user_id'=> $request->user_id,
            'category_id' => $request->addcategory,
            'title' => $request->title,
            'description'=>$request->description,
            'articles_image'=>strtolower(Str::replaceLast(' ','',$request->Category)).'/'.$image->getClientOriginalName()]
        );
        $category = Category::all();

        return redirect('/blog')->with(['Category'=>$category]);
    }
    
    public function update_profil(Request $request, $id){ // untuk mengupdate profile user
        $validator = Validator::make($request->all(), [
            'name'=>'required|max:255',
            'email' => 'required|unique:users',
            'phone' => 'required|numeric',
        ]);
        if ($validator->fails()) {
            return redirect('add')
                        ->withErrors($validator)
                        ->withInput();
        }

        DB::table('users')->where('id', $id)->update(
            ['name'=> $request->name,
            'email' => $request->email,
            'phone' => $request->phone,
            ]
        );
        $users = User::all();

        return redirect('/home')->with(['users'=>$users]);
    }

    public function view_update($id){ // untuk melihat profile
        $users = User::where('id',$id)->first();
        return view('profile', ['users'=>$users]);
    }


    
}
