<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Articles;
use App\Category;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('home');
    }

    public function view_home($id){ // untuk melihat halaman home
        $articles = DB::table('articles')->join('categories','articles.category_id', '=', 'categories.id')->select('articles.*', 'categories.name')->paginate(6);
        $category = Category::where('id',$id)->first();
        return view('home',['articles'=>$articles, 'categories'=>$category]);
    }

    public function detail($id){  // untuk melihat detail articles
        $articles = DB::table('articles')->where('id',$id)->first();
        return view('detail',['articles'=>$articles]);
    }

    function Logout(){ // untuk logout
        Auth::logout();
        return redirect('/home');
    }
}
