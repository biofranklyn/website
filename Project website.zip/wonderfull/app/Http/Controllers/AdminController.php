<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Facades\DB;

class AdminController extends Controller
{
    public function view_user(){ // untuk admin melihat user
        $user = User::all();
        return view ('adminuser', ['users'=>$user]);
    }

    public function delete($id){ // untuk admin mendelete user
        DB::table('users')->where('id',$id)->delete();
        return redirect('/adminuser');
    }
}
