<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Articles;
use App\Category;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class GuestController extends Controller
{
    public function goHome(){ // untuk guest melihat articles 
        $articles = Articles::paginate(6);
        return view('home',['articles'=>$articles]);
    }

    public function category($id){ // untuk category
        $articles = Articles::where('category_id',$id)->get();
        $category = Category::where('id',$id)->first();
        return view('category',['articles'=>$articles, 'categories'=>$category]);
    }

    public function detail($id){ // untuk guest melihat detail articles
        $articles = DB::table('articles')->where('id',$id)->first();
        return view('detail',['articles'=>$articles]);
    }
}
