@extends('layouts/app')

@section('style')
    <style>
        .label{
            padding-left: 150px;
        }
    </style>
@section('containers')
<div class="containers">
    <div class="content">
        <form action="/update/user/{{$users->id}}" method="post">
            @csrf
            <div class="form-group row">
                <label for="name" class="label col-sm-2 col-form-label">Name</label>
                <div class="col-sm-10" style="width: 40px; margin-left: 130px">
                  <input type="text" class="form-control" id="name" name="name" required>
                </div>
            </div>
            <div class="form-group row">
                <label for="email" class="label col-sm-2 col-form-label">Email</label>
                <div class="col-sm-10" style="width: 40px; margin-left: 130px">
                  <input type="text" class="form-control" id="email" name="email" required>
                </div>
            </div>
            <div class="form-group row">
                <label for="phone" class="label col-sm-2 col-form-label">Phone</label>
                <div class="col-sm-10" style="width: 40px; margin-left: 130px">
                  <input type="text" class="form-control" id="phone" name="phone" required>
                </div>
            </div>
            <div class="col-sm-10" style="margin-left: 150px">
                <input type="submit" class="btn btn-primary" value="Update">
            </div>
        </form>
        
    </div>
</div>
    
@endsection
@endsection