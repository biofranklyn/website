@extends('layouts/app')

@section('style')
    <style>
    .content2{
        padding-top: 10px;
        display: block;
        width: 350px;
        padding-left: 100px;
    }
    .category{
        font-size: 14px;
        font-style: italic;
    }

    .text{
        width: 300px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    .title{
        width: 300px;
    }
    .img{
        width: 300px;
    }
    </style>

    
@section('containers')
<div class="containers">
    <div class="content">
        @if (count($articles) > 0 )
            @foreach ($articles->chunk(3) as $art)
            <div class="row  mt-5 mx-5 d-flex justify-content-center">
                @foreach ($art as $ar)
                    <div class="col-3 content2 py-2 px-0 mx-1 ">
                        <img class="img" src="{{asset('asset/'.$ar->articles_image ) }}" alt="{{$ar->articles_image }}">
                        <h4 class="title">
                            {{$ar->title}}
                        </h4>
                            <p class="text" style="font-size: 15px">
                                {{$ar->description}}
                                
                            </p>   
                            <a href="/guestdetail/{{$ar->id}}">see more</a>
                            <h6 class="category" style="font-size: 13px">
                                Category: <a href="/category/{{$ar->category_id}}">{{$ar->Category->name}}</a>
                            </h6>                   
                    </div>
                @endforeach
            </div>                   
            @endforeach
            <div class="scrolltable mt-2 mx-auto w-50 h-50 d-flex justify-content-end">
                {{$articles->Links()}}
            </div>
            @else
            <div class="row mt-5 mx-5 d-flex justify-content-home">
                <h3>
                    Welcome, tell us your experience when you’re on vacation
                </h3>
            </div>
            @endif
    </div>
    
</div>
    
@endsection
@endsection