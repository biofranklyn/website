@extends('layouts/app')

@section('style')
    <style>
body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}

html {
  box-sizing: border-box;
}

*, *:before, *:after {
  box-sizing: inherit;
}

.column {
  float: left;
  width: 33.3%;
  margin-bottom: 16px;
  padding: 0 8px;
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  margin: 8px;
  margin-left: 20px;
}

.about-section {
  padding: 50px;
  text-align: center;
  background-color: #474e5d;
  color: white;
}

.container {
  padding: 0 16px;
}

.container::after, .row::after {
  content: "";
  clear: both;
  display: table;
}

.title {
  color: grey;
}

.button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
}

.button:hover {
  background-color: #555;
}

@media screen and (max-width: 650px) {
  .column {
    width: 100%;
    display: block;
  }
}
    </style>
@section('containers')
    <div class="about-section">
        <h1>About Us</h1>
        <p>Website kami hanya melihat dan menambahkan review tempat wisata di Indonesia</p>
      </div>
      <div class="row d-flex justify-content-center">
        <div class="column">
          <div class="card ">
            <div class="container">
              <h2>Muhammad Bio Franklyn</h2>
              <h3>2201843153</h3>
              <p class="title">CEO & Founder</p>
              <p>
                  Saya selaku CEO & Founder dari website ini, 
                  saya membbuat website ini karena ini adalah 
                  tugas project dari jurusan mengenai Ulangan 
                  akhir semester jika terjadi kendala dalam 
                  website saya bisa menghubungi saya melalui 
                  contact di bawah terimakasih.
              </p>
              <p>E-mail : biovanklyn@gmail.com</p>
              <p>Whatsapp : 081293599608</p>
            </div>
          </div>
        </div>
      </div>
    
@endsection
@endsection