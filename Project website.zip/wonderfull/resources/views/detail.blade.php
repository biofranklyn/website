@extends('layouts/app')

@section('style')
    <style>
    .content2{
        display: inline-block;
        width: 500px;
        padding-left: 100px;
    }
    .img{
        width: 300px;
    }
    </style>
@section('containers')
<div class="containers">
    <div class="content">
        <div class="content2">
                <img class="img" src="{{asset('asset/'.$articles->articles_image ) }}" alt="{{asset('asset/'.$articles->articles_image ) }}">
            <h3>
                {{$articles->title}}
            </h3>
            
            <p>
                {{$articles->description}}
            </p>
            <a href="{{url()->previous()}}">Back</a> 
        </div>
    </div>
</div>
    
@endsection
@endsection