@extends('layouts/app')

@section('style')
    <style>
        .content{
            padding-left: 525px;
            width: 1000px;
            text-align: center;
        }
    </style>
@section('containers')
<div class="containers">
    <div class="content">
      <table class="table table-striped">
        <thead>
            <tr>
              <th scope="col">User</th>
              <th scope="col">E-mail</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          @foreach ($users as $us)
          <tr>
            <td>
                <p class="text">
                    {{$us->name}}
                </p>
            </td>
            <td>
              <p class="text">
                  {{$us->email}}
              </p>
          </td>
            <td>
                <a href="/adminuser/delete/{{ $us->id }}"class="btn btn-primary" style="font-size: 11px">Delete</a>
            </td>
            </tr>
          @endforeach
          
    </table>
    </div>
</div>
    
@endsection
@endsection