@extends('layouts/app')

@section('style')
    <style>
        .category{
          width: 800px;
        }
    </style>
@section('containers')
<div class="containers">
    <div style="width: 100%; height: 788px;">
          <div style="width: 60%; height: 680px; margin-left: auto; margin-right: auto">
              <form action="/add/articles" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="container text-center pt-3">
                    <h3> New Blog </h3>
                </div>
                @if ($errors->any())
                    <div class="row">
                      <div class="col danger text-danger">
                        <ul>
                          @foreach ($errors->all() as $err)
                              <li>{{$err}}</li>
                          @endforeach
                        </ul>
                      </div>
                    </div>
                @endif
                <div class="form-group row">
                  <label for="title" class="col-sm-2 col-form-label">Title</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="title" name="title" required>
                  </div>
                </div>

                <div class="form-group row">
                <label for="category" class="col-sm-2 col-form-label">Category</label>
                  <div class="col-sm-10">
                  <select id="inputState" class="form-control" name="addcategory" required>
                    <option selected>Choose...</option>
                    <option value="1">Beach</option>
                    <option value="2">Mountain</option>
                    <option value="3">City</option>
                  </select>
                  </div>
                </div>
                <input type="hidden" class="inpt form-control" name="user_id" id="user_id" value="{{Auth::user()->id}}">
                <div class="form-group row">
                  <label style="margin-left: 15px"for="img">Image</label>
                  <div class="col-sm-10" style="padding-left: 103px">
                      <input type="file" class="inpt form-control" name="articles_image" id="image">
                  </div>
                </div>

                <div class="form-group row">
                  <label for="inputAddress" class="col-sm-2 col-form-label">Story</label>
                  <div class="col-sm-10">
                    <textarea class="form-control" placeholder="Input Your Story" id="description" name="description" style="height: 100px"></textarea>
                  </div>
                </div>
                  
                <div class="col-sm-10" style="margin-left: 157px">
                    <input type="submit" class="btn btn-primary" value="Create blog">
                </div>
              </form>
        </div>
    </div>
</div>
    
@endsection
@endsection