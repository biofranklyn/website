<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/login', function () {
//     return view('welcome');
// });

Route::get('/aboutus',function(){
    return view('aboutus');
});

Route::get('/detail',function(){
    return view('detail');
});
Route::get('/category', function(){
    return view('category');
});
Route::get('/createblog', function(){
    return view('createblog');
});

// Route::get('/blog', function(){
//     return view('blog');
// });

// Route::get('/useradmin', function(){
//     return view('adminuser');
// });

Route::get('/profil', function(){
    return view('profile');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/home/{id}', 'HomeController@view_home')->name('home');

Route::get('/home/detail/{id}', 'HomeController@detail')->name('home');
Route::get('/', 'GuestController@goHome')->name('home');
Route::get('/home', 'GuestController@goHome')->name('home');
Route::get('/guestdetail/{id}', 'GuestController@detail')->name('home');

Route::post('/update/user/{id}', 'UserController@update_profil');

Route::get('/update/{id}','UserController@view_update');


Route::post('/add/articles', 'UserController@AddArticles');
Route::get('/articles/hapus/{id}','UserController@delete');
Route::get('/blog', 'UserController@muncul_articles');

Route::get('/category/{id}', 'GuestController@category')->name('category');

Route::get('/adminuser', 'AdminController@view_user');
Route::get('/adminuser/delete/{id}','AdminController@delete');

Route::get('/singout', 'HomeController@Logout');
