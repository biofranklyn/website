

<?php $__env->startSection('style'); ?>
    <style>
    .content2{
        display: inline-block;
        width: 500px;
        padding-left: 100px;
    }
    .img{
        width: 300px;
    }
    </style>
<?php $__env->startSection('containers'); ?>
<div class="containers">
    <div class="content">
        <div class="content2">
                <img class="img" src="<?php echo e(asset('asset/'.$articles->articles_image )); ?>" alt="<?php echo e(asset('asset/'.$articles->articles_image )); ?>">
            <h3>
                <?php echo e($articles->title); ?>

            </h3>
            
            <p>
                <?php echo e($articles->description); ?>

            </p>
            <a href="<?php echo e(url()->previous()); ?>">Back</a> 
        </div>
    </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Wonderfull Jorney\wonderfull\resources\views/detail.blade.php ENDPATH**/ ?>