<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Wonderful Journey</title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    

    <style>
    body{
        font-family: 'Times New Roman';
    }
    .header{
        padding-top: 30px;
        text-align: center;
        background: #c0c0c0;
        padding-bottom: 30px;
    }
    </style>
    <?php echo $__env->yieldContent('style'); ?>
</head>
<body>
    <div id="app">
        <div class="header">
            <h1 class="judul">
                Wonderful Journey
            </h1>
            <h6 class="mb-1">
                Blog of Indonesia Tourism
            </h6>
        </div>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="/">Home</a>
        </li>
        <?php if(Auth::check() && Auth::user()->role == 0): ?>
          <li class="nav-item">
            <a class="nav-link" href="/update/<?php echo e(Auth::user()->id); ?>">Profil</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/blog">Blog</a>
          </li>
        <?php elseif(Auth::check() && Auth::user()->role == 1): ?>
        <li class="nav-item">
          <a class="nav-link" href="/blog">Admin</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/adminuser">Users</a>
        </li>
        <?php endif; ?>

       <?php if(auth()->guard()->guest()): ?>
       <ul class="navbar-nav">
        <li class="nav-item dropdown"> 
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Category
            </a>
            <div class="dropdown-menu" style="position: absolute;" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="/category/1">Beaches</a>
              <a class="dropdown-item" href="/category/2">Mountains</a>
              <a class="dropdown-item" href="/category/3">City</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="/">Home</a>
            </div>
        </li> 
        </ul>
        <li class="nav-item">
        <a class="nav-link" href="/aboutus">About Us</a>
        </li>
       <?php endif; ?>
        
        
      </ul>
    </div>

    <ul class="navbar-nav ml-auto">
      <!-- Authentication Links -->
      <?php if(auth()->guard()->guest()): ?>
          <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
          </li>
          <?php if(Route::has('register')): ?>
              <li class="nav-item">
                  <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
              </li>
          <?php endif; ?>
      <?php else: ?>
          <li class="nav-item dropdown">
              <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                  <?php echo e(Auth::user()->name); ?>

              </a>

              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                  <a class="dropdown-item" href="/singout"
                     onclick="event.preventDefault();
                                   document.getElementById('logout-form').submit();">
                      <?php echo e(__('Logout')); ?>

                  </a>

                  <form id="logout-form" action="/singout" method="GET" class="d-none">
                      <?php echo csrf_field(); ?>
                  </form>
              </div>
          </li>
      <?php endif; ?>
  </ul>
  </div>
</nav>
        <main class="">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
    <?php echo $__env->yieldContent('containers'); ?>
</body>
</html>
<?php /**PATH D:\Wonderfull Jorney\wonderfull\resources\views/layouts/app.blade.php ENDPATH**/ ?>