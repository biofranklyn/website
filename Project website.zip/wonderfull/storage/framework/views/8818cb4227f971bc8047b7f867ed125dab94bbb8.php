

<?php $__env->startSection('style'); ?>
    <style>
        .content{
            padding-left: 525px;
            width: 1000px;
           
        }
    </style>
<?php $__env->startSection('containers'); ?>
<div class="containers">
    <div class="content">
        <a href="/createblog" class="btn btn-secondary btn-md">+ Create blog</a>
    <table class="table table-striped">
        <thead>
            <tr>
              <th scope="col">Title</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td>
                <p class="text">
                    <?php echo e($article->title); ?>

                </p>
            </td>
            <td>
                <a href="/articles/hapus/<?php echo e($article->id); ?>"class="btn btn-primary" style="font-size: 11px">Delete</a>
            </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Wonderfull Jorney\wonderfull\resources\views/blog.blade.php ENDPATH**/ ?>