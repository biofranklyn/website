

<?php $__env->startSection('style'); ?>
    <style>
        .content{
            padding-left: 525px;
            width: 1000px;
            text-align: center;
        }
    </style>
<?php $__env->startSection('containers'); ?>
<div class="containers">
    <div class="content">
      <table class="table table-striped">
        <thead>
            <tr>
              <th scope="col">User</th>
              <th scope="col">E-mail</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td>
                <p class="text">
                    <?php echo e($us->name); ?>

                </p>
            </td>
            <td>
              <p class="text">
                  <?php echo e($us->email); ?>

              </p>
          </td>
            <td>
                <a href="/adminuser/delete/<?php echo e($us->id); ?>"class="btn btn-primary" style="font-size: 11px">Delete</a>
            </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
    </table>
    </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Wonderfull Jorney\wonderfull\resources\views/adminuser.blade.php ENDPATH**/ ?>