

<?php $__env->startSection('style'); ?>
    <style>
        .inpt{}
    </style>
<?php $__env->startSection('containers'); ?>
<div class="containers">
    <div style="width: 100%; height: 788px;">
        <div style="width: 60%; height: 680px; margin-left: auto; margin-right: auto">
            <form action="/add/flower" method="POST" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <div class="container text-center pt-3">
                  <h3> New Blog </h3>
              </div>
              <?php if($errors->any()): ?>
                  <div class="row">
                    <div class="col danger text-danger">
                      <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($err); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </ul>
                    </div>
                  </div>
              <?php endif; ?>
              <div class="form-group row">
              <label for="category" class="col-sm-2 col-form-label">Category</label>
                  <select name="category" id="category" style="margin-left: 15px; font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif" required>
                  <option value="Beaches" style="font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif">Beaches</option>
                  <option value="Bouquet" style="font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif">Bouquet</option>
                  <option value="Mountains" style="font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif">Mountains</option>
                  <option value="Places" style="font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif">Places</option>
                  </select>
              </div>
              <div class="form-group row">
                <label for="title" class="col-sm-2 col-form-label">Title</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" id="title" name="title" required>
                </div>
              </div>
              <div class="form-group row">
                <label style="margin-left: 15px"for="img">Image</label>
                <div class="col-sm-10" style="width: 20px; margin-left: 100px">
                    <input type="file" class="inpt form-control" id="image">
                </div>
                </div>
                <div class="form-group row">
                  <label for="inputAddress" class="col-sm-2 col-form-label">Story</label>
                  <div class="col-sm-10">
                    <textarea class="form-control" placeholder="Input Your Story" id="floatingTextarea2" style="height: 100px"></textarea>
                  </div>
                </div>
                
                <div class="col-sm-10" style="margin-left: 157px">
                    <input type="submit" class="btn btn-primary" value="Add Flower">
                </div>
                </form>
        </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Wonderfull Jorney\wonderfull\resources\views/bloguser.blade.php ENDPATH**/ ?>