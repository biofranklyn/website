

<?php $__env->startSection('style'); ?>
    <style>
    .content2{
        display: inline-block;
        width: 350px;
        padding-left: 100px;
    }
    </style>
<?php $__env->startSection('containers'); ?>
<div class="containers">
    <div class="content">
        <div class="content2">
            <h3>
                Pantai Kuta, Bali
            </h3>
            <p>
                pantai kuta adalah sebuah tempat pariwisata
                yang terletak kecamatan kuta. sebelah <a href="">full story</a>
            </p> 
        </div>
        <div class="content2">
            <h3>
                Pantai Kuta, Bali
            </h3>
            <p>
                pantai kuta adalah sebuah tempat pariwisata
                yang terletak kecamatan kuta. sebelah <a href="">full story</a>
            </p>
        </div>
        <div class="content2">
            <h3>
                Pantai Kuta, Bali
            </h3>
            <p>
                pantai kuta adalah sebuah tempat pariwisata
                yang terletak kecamatan kuta. sebelah <a href="">full story</a>
            </p>
        </div>
    </div>
    
</div>
    
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Wonderfull Jorney\wonderfull\resources\views/homepage.blade.php ENDPATH**/ ?>