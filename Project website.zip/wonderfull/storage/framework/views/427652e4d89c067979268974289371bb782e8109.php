

<?php $__env->startSection('style'); ?>
    <style>
    .content2{
        padding-top: 10px;
        display: block;
        width: 350px;
        padding-left: 100px;
    }
    .category{
        font-size: 14px;
        font-style: italic;
    }

    .text{
        width: 300px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        
    }
    .title{
        width: 300px;
    }
    .img{
        width: 300px;
    }
    </style>

    
<?php $__env->startSection('containers'); ?>
<div class="containers">
    <div class="content">
        <div class="tulisan text-center d-flex justify-content-center">
            <h3 class="category mt-3" style="font-size: 20px">
                <?php echo e($categories->name); ?>

            </h3>
        </div>
        <?php if(count($articles)>0): ?>
        <?php $__currentLoopData = $articles->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $art): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row  mt-5 mx-5 d-flex justify-content-center">
            <?php $__currentLoopData = $art; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-3 content2 py-2 px-0 mx-1 ">
                    <img class="img" src="<?php echo e(asset('asset/'.$ar->articles_image )); ?>" alt="<?php echo e($ar->articles_image); ?>">
                    <h4 class="title">
                        <?php echo e($ar->title); ?>

                    </h4>
                        <p class="text" style="font-size: 15px">
                            <?php echo e($ar->description); ?>

                            
                        </p>   
                        <a href="/home/detail/<?php echo e($ar->id); ?>">see more</a>
                        <h6 class="category" style="font-size: 13px;">
                            Category: <a href="#"><?php echo e($ar->category->name); ?></a>
                        </h6>                   
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>                   
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <h3>
            Wellcome, tell us your experience when you’re on vacation
        </h3>
        <?php endif; ?>
    </div>   
</div>
    
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Wonderfull Jorney\wonderfull\resources\views/category.blade.php ENDPATH**/ ?>