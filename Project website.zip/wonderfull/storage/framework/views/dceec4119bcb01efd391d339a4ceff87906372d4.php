

<?php $__env->startSection('style'); ?>
    <style>
    .content2{
        padding-top: 10px;
        display: block;
        width: 350px;
        padding-left: 100px;
    }
    .category{
        font-size: 14px;
        font-style: italic;
    }

    .text{
        width: 300px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    .title{
        width: 300px;
    }
    .img{
        width: 300px;
    }
    </style>

    
<?php $__env->startSection('containers'); ?>
<div class="containers">
    <div class="content">
        <?php if(count($articles) > 0 ): ?>
            <?php $__currentLoopData = $articles->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $art): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row  mt-5 mx-5 d-flex justify-content-center">
                <?php $__currentLoopData = $art; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-3 content2 py-2 px-0 mx-1 ">
                        <img class="img" src="<?php echo e(asset('asset/'.$ar->articles_image )); ?>" alt="<?php echo e($ar->articles_image); ?>">
                        <h4 class="title">
                            <?php echo e($ar->title); ?>

                        </h4>
                            <p class="text" style="font-size: 15px">
                                <?php echo e($ar->description); ?>

                                
                            </p>   
                            <a href="/guestdetail/<?php echo e($ar->id); ?>">see more</a>
                            <h6 class="category" style="font-size: 13px">
                                Category: <a href="/category/<?php echo e($ar->category_id); ?>"><?php echo e($ar->Category->name); ?></a>
                            </h6>                   
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>                   
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="scrolltable mt-2 mx-auto w-50 h-50 d-flex justify-content-end">
                <?php echo e($articles->Links()); ?>

            </div>
            <?php else: ?>
            <div class="row mt-5 mx-5 d-flex justify-content-home">
                <h3>
                    Welcome, tell us your experience when you’re on vacation
                </h3>
            </div>
            <?php endif; ?>
    </div>
    
</div>
    
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Wonderfull Jorney\wonderfull\resources\views/home.blade.php ENDPATH**/ ?>