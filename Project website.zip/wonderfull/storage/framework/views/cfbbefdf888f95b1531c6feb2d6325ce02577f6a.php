

<?php $__env->startSection('style'); ?>
    <style>
        .label{
            padding-left: 150px;
        }
    </style>
<?php $__env->startSection('containers'); ?>
<div class="containers">
    <div class="content">
        <form action="/update/user/<?php echo e($users->id); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group row">
                <label for="name" class="label col-sm-2 col-form-label">Name</label>
                <div class="col-sm-10" style="width: 40px; margin-left: 130px">
                  <input type="text" class="form-control" id="name" name="name" required>
                </div>
            </div>
            <div class="form-group row">
                <label for="email" class="label col-sm-2 col-form-label">Email</label>
                <div class="col-sm-10" style="width: 40px; margin-left: 130px">
                  <input type="text" class="form-control" id="email" name="email" required>
                </div>
            </div>
            <div class="form-group row">
                <label for="phone" class="label col-sm-2 col-form-label">Phone</label>
                <div class="col-sm-10" style="width: 40px; margin-left: 130px">
                  <input type="text" class="form-control" id="phone" name="phone" required>
                </div>
            </div>
            <div class="col-sm-10" style="margin-left: 150px">
                <input type="submit" class="btn btn-primary" value="Update">
            </div>
        </form>
        
    </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Wonderfull Jorney\wonderfull\resources\views/profile.blade.php ENDPATH**/ ?>