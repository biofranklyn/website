<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    
    <script src="<?php echo e(asset ('jquery/jquery-3.5.1.min.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset ('bootstrap/css/bootstrap.min.css')); ?>">
    <script src="<?php echo e(asset ('bootstrap/js/bootstrap.min.js')); ?>"></script>
    

    <style>
    body{
        font-family: 'Times New Roman';
    }
    .header{
        padding-top: 30px;
        text-align: center;
        background: #c0c0c0;
        padding-bottom: 30px;
    }
    </style>
    <?php echo $__env->yieldContent('style'); ?>
</head>
<body>
        <div class="header">
            <h1 class="judul">
                Wonderful Journey
            </h1>
            <h6 class="mb-1">
                Blog of Indonesia Tourism
            </h6>
        </div>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="/home">Home</a>
        </li>
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Category
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
              <li><a class="dropdown-item" href="#">Action</a></li>
              <li><a class="dropdown-item" href="#">Another action</a></li>
              <li><a class="dropdown-item" href="#">Something else here</a></li>
            </ul>
          </li>
        <li class="nav-item">
          <a class="nav-link" href="#">About Us</a>
        </li>
      </ul>
    </div>
    <ul class="navbar-nav">
        <li class="nav-item">
            <i class="bi bi-person-fill"></i>
            <a class="nav-link" href="#">Sign Up</a>
         </li>
         <li class="nav-item">
            <a class="nav-link" href="#">Login</a>
         </li>
    </ul>
  </div>
</nav>
<?php echo $__env->yieldContent('containers'); ?>
</body>
</html><?php /**PATH D:\Wonderfull Jorney\wonderfull\resources\views/layout/layout.blade.php ENDPATH**/ ?>